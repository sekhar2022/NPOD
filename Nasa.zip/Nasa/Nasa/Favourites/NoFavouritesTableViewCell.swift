//
//  NoFavouritesTableViewCell.swift
//  Nasa
//
//  Created by Chandra Sekhar Y on 24/01/22.
//

import UIKit

class NoFavouritesTableViewCell: UITableViewCell {

    @IBOutlet weak var noItemsLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
